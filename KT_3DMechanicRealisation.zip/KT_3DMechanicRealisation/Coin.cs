using UnityEngine;

namespace N
{
    public class Coin : MonoBehaviour
    {
        [SerializeField] private int _cost = 1;
        [SerializeField] private Wallet _wallet;
        [SerializeField] private LayerMask _whatCanTake;

        private void OnTriggerEnter(Collider other)
        {
            if (IsInLayer(other.gameObject.layer, _whatCanTake))
            {
                _wallet.AddCoins(_cost);
                Destroy(gameObject);
            }
        }

        private bool IsInLayer(int layer, LayerMask mask)
        {
            return ((1 << layer) & mask) != 0;
        }
    }
}