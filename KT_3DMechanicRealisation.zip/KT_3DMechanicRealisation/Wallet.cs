using TMPro;
using UnityEngine;

namespace N
{
    public class Wallet : MonoBehaviour
    {
        [SerializeField] private int _balance;

        [SerializeField] private GameObject _walletCanvas;
        [SerializeField] private TextMeshProUGUI _balanceText;

        private void Start()
        {
            UpdateUI();
        }

        public void AddCoins(int amount)
        {
            _balance += amount;
            UpdateUI();
        }

        private void UpdateUI()
        {
            if (_balanceText != null)
                _balanceText.text = "Wallet: " + _balance;
        }
    }
}