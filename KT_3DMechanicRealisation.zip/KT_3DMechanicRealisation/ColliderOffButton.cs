using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ColliderOffButton : MonoBehaviour
{
    [SerializeField] private LayerMask _whatCanToPressed;

    private void OnCollisionEnter(Collision collision)
    {
        if ((1 << collision.gameObject.layer & _whatCanToPressed) != 0f)
        {
            collision.collider.enabled = false;
            StartCoroutine(RestartLevel());
        }
    }

    private IEnumerator RestartLevel()
    {
        yield return new WaitForSeconds(2f);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
