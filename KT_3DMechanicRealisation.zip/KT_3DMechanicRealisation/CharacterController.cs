using UnityEngine;
using UnityEngine.InputSystem;

namespace Lol
{
    public class CharacterController : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private Rigidbody _rigidbody;

        [Header("Movement")]
        [SerializeField] private float _moveSpeed = 5f;
        [SerializeField] private float _rotateSpeed = 180f;
        [SerializeField] private float _jumpPower = 5f;

        [Header("Input")]
        [SerializeField] private InputActionReference _moveAction;
        [SerializeField] private InputActionReference _jumpAction;

        [Header("Ground")]
        [SerializeField] private LayerMask _whatIsGround;

        private Vector2 _movementInput;
        private bool _canJump;
        private bool _isGrounded;

        private void OnEnable()
        {
            _moveAction.action.Enable();
            _jumpAction.action.Enable();

            _jumpAction.action.performed += OnJump;
        }

        private void OnDisable()
        {
            _jumpAction.action.performed -= OnJump;

            _moveAction.action.Disable();
            _jumpAction.action.Disable();
        }

        private void Update()
        {
            _movementInput = _moveAction.action.ReadValue<Vector2>();
        }

        private void FixedUpdate()
        {
            if (_canJump && _isGrounded)
            {
                _rigidbody.linearVelocity = new Vector3(
                    _rigidbody.linearVelocity.x,
                    _jumpPower,
                    _rigidbody.linearVelocity.z
                );

                _canJump = false;
            }

            Vector3 movement =
                transform.forward *
                _movementInput.y *
                _moveSpeed *
                Time.fixedDeltaTime;

            _rigidbody.MovePosition(_rigidbody.position + movement);

            Quaternion rotation = Quaternion.Euler(
                0f,
                _movementInput.x * _rotateSpeed * Time.fixedDeltaTime,
                0f
            );

            _rigidbody.MoveRotation(_rigidbody.rotation * rotation);
        }

        private void OnJump(InputAction.CallbackContext context)
        {
            _canJump = true;
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (((1 << collision.gameObject.layer) & _whatIsGround.value) != 0)
            {
                _isGrounded = true;
            }
        }

        private void OnCollisionExit(Collision collision)
        {
            if (((1 << collision.gameObject.layer) & _whatIsGround.value) != 0)
            {
                _isGrounded = false;
            }
        }
    }
}