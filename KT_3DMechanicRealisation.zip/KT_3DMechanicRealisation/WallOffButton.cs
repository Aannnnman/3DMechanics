using UnityEngine;

public class WallOffButton : MonoBehaviour
{
    [SerializeField] private GameObject _wall;
    [SerializeField] private LayerMask _whatCanToPressed;

    private void OnCollisionEnter(Collision collision)
    {
        if ((1 << collision.gameObject.layer & _whatCanToPressed) != 0f)
            _wall.SetActive(false);
    }

    private void OnCollisionExit(Collision collision)
    {
        if ((1 << collision.gameObject.layer & _whatCanToPressed) != 0f)
            _wall.SetActive(true);
    }
}
