using UnityEngine;

public class GameObjectActivateTrigger : MonoBehaviour
{
    [SerializeField] private GameObject _activateObject;
    [SerializeField] private LayerMask _whatCanToActivate;

    private void OnTriggerEnter(Collider other)
    {
        if (IsInLayer(other.gameObject.layer, _whatCanToActivate))
        {
            _activateObject.SetActive(true);
        }
    }

    private bool IsInLayer(int layer, LayerMask mask)
    {
        return ((1 << layer) & mask) != 0;
    }
}
