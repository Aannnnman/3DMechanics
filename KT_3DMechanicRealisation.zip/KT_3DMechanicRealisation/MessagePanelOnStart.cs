using UnityEngine;

public class MessagePanelOnStart : MonoBehaviour
{
    [SerializeField] private GameObject _messagePanel;

    private void Start()
    {
        _messagePanel.gameObject.SetActive(true);
    }

    private void Update()
    {
        if (Input.anyKeyDown)
        {
            _messagePanel.gameObject.SetActive(false);
        }
    }
}
