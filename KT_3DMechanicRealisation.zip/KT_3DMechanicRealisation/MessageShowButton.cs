using UnityEngine;

public class MessageShowButton : MonoBehaviour
{
    [SerializeField] private GameObject _panelWithMessage;
    [SerializeField] private LayerMask _whatCanToPressed;

    private void OnCollisionEnter(Collision collision)
    {
        if ((1 << collision.gameObject.layer & _whatCanToPressed) != 0f)
            _panelWithMessage.SetActive(true);
    }

    private void OnCollisionExit(Collision collision)
    {
        if ((1 << collision.gameObject.layer & _whatCanToPressed) != 0f)
            _panelWithMessage.SetActive(false);
    }
}
