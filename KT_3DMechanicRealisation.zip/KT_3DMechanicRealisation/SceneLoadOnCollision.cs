using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoadOnCollision : MonoBehaviour
{
    [SerializeField] private string _sceneName;
    [SerializeField] private LayerMask _whatCanToLoadScene;

    private void OnCollisionEnter(Collision collision)
    {
        if (IsInLayer(collision.collider.gameObject.layer, _whatCanToLoadScene))
        {
            SceneManager.LoadScene(_sceneName);
            //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    private bool IsInLayer(int layer, LayerMask mask)
    {
        return ((1 << layer) & mask) != 0;
    }
}
